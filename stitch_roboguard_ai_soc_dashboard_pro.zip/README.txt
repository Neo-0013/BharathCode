ROBOGUARD AI offline bundle. Open index.html / soc_dashboard.html directly in any modern browser. No network required (Three.js + GSAP are inlined).
